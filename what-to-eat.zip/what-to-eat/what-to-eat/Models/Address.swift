//
//  Address.swift
//  what-to-eat
//
//  Created by 최은성 on 2021/12/30.
//

import Foundation


struct Address {
    let lat: Double
    let lng: Double
    let name: String
    let str: String
    init(str: String) {
        self.str = str
        let arr = str.components(separatedBy: "/")
        name = arr[3]
        let arr2 = arr[4].components(separatedBy: ["@",","])
        lat = Double(arr2[1]) ?? 0
        lng = Double(arr2[2]) ?? 0
        print("이름: \(name),위치: \(lat), \(lng)")
        
    }
}
