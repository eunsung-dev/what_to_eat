//
//  File.swift
//  what-to-eat
//
//  Created by 최은성 on 2021/12/30.
//

import Foundation
// https:// 혹은 http:// 제외 후 나머지 주소를 복사
//var str = "www.google.co.kr/maps/place/서울성자초등학교/@37.5313243,127.0809589,17z/data=!3m1!4b1!4m5!3m4!1s0x357ca51d8858a0a7:0x733f410aaa4c45c0!8m2!3d37.5313201!4d127.0831476?hl=ko"
//var arr = str.components(separatedBy: "/")
//print(arr)
//print("지역: \(arr[3])")
//var arr2 = arr[4].components(separatedBy: ["@",","])
//let latt = arr2[2]
//let lngg = arr2[2]
//print("위치: \(arr2)")

struct TotalString {
    let str = [
               Address(str: "www.google.co.kr/maps/place/김삼보+종로점/@37.5706571,126.9803325,16z/data=!4m5!3m4!1s0x357ca31f96fe1b1f:0x9399ac0a92e31237!8m2!3d37.5706571!4d126.9803325?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/교동전선생+종로구청점/@37.5722388,126.9805102,17z/data=!4m5!3m4!1s0x357ca2e8d091640f:0x4eeec81c2c3d6493!8m2!3d37.5722388!4d126.9805102?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/정통삼계탕원가/@37.5741303,126.9791603,17z/data=!4m8!1m2!2m1!1z6rSR7ZmU66y4IOyghO2GteyCvOqzhO2DlQ!3m4!1s0x357ca2ea69cfbc85:0xe1792b2a26a5b5b5!8m2!3d37.5741303!4d126.9791603?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/대추나무집/@37.5726174,126.9805524,16z/data=!4m5!3m4!1s0x357ca2ea2c6b8115:0x19c4700305000a3b!8m2!3d37.5726174!4d126.9805524?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/홍차오+종로본점/@37.5708033,126.9798544,16z/data=!4m8!1m2!2m1!1z6rSR7ZmU66y4IO2ZjeywqOyYpA!3m4!1s0x357ca2ebf3b376c1:0xa8be3a2ec5ca95d1!8m2!3d37.5708033!4d126.9798544?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/영양버섯칼국수/@37.5713049,126.972836,16z/data=!4m8!1m2!2m1!1z7ISd7YOE7ZqM6rSAIOuyhOyEr-y5vOq1reyImA!3m4!1s0x357ca2930828b703:0x9e88676c7c6de504!8m2!3d37.5713049!4d126.972836?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/전주밥차/@37.5754163,126.9801322,16z/data=!4m5!3m4!1s0x357ca2c1e576040d:0xa1c163cb0467df8b!8m2!3d37.5754163!4d126.9801322?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/완차이면가+오피시아점/@37.5696468,126.9748812,18z/data=!4m8!1m2!2m1!1z6rSR7ZmU66y4IOyZleywqOydtOuptOqwgA!3m4!1s0x357ca3caafde374b:0x2a630e84299668f5!8m2!3d37.5697259!4d126.9749344?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/깡장집/@37.5717719,126.9819244,16z/data=!4m8!1m2!2m1!1z6rmh7J6l7KeR!3m4!1s0x357ca3d340a27f7b:0xb5742523d9efa0fc!8m2!3d37.5720202!4d126.9816796?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/도렴빌딩+지하상가+양반댁/@37.5734082,126.9742091,16z/data=!4m5!3m4!1s0x357ca3e89bda3c51:0x754b99941ae79d40!8m2!3d37.5734082!4d126.9742091?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/신의주+찹쌀순대+광화문점/@37.573719,126.9739994,15z/data=!4m8!1m2!2m1!1z64-E66C067mM65SpIOq3vOyymCDsi6DsnZjso7zqta3rsKU!3m4!1s0x357ca293845d7bfd:0xe6d9ea5d9495feb8!8m2!3d37.5726536!4d126.9724911?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/담소사골순대+북창점/@37.5637457,126.9774301,16z/data=!4m5!3m4!1s0x357ca2f31081373f:0x3e4b6b3875f656fc!8m2!3d37.5637457!4d126.9774301?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/해장국사람들/@37.5805104,126.9713769,16z/data=!4m5!3m4!1s0x357ca2be8a633e69:0x890595b443cea144!8m2!3d37.5805104!4d126.9713769?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/종갓집/@37.5856072,126.9700737,16z/data=!4m8!1m2!2m1!1z6rSR7ZmU66y4IOyiheqwgOynkQ!3m4!1s0x357ca2b98763d9d9:0x99766f14e9672281!8m2!3d37.5857942!4d126.9702454?hl=ko"),
               Address(str: "www.google.co.kr/maps/place/남산왕돈까스/@37.5646729,126.9838466,17z/data=!4m8!1m2!2m1!1z7KSR6rWt64yA7IKs6rSAIOuCqOyCsOyZleuPiOq5jOyKpA!3m4!1s0x357ca2ee2b660ea7:0xf995a84313ac1eea!8m2!3d37.5646729!4d126.9838466?hl=ko")
    ]
}
