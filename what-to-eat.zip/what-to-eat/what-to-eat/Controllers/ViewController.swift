//
//  ViewController.swift
//  what-to-eat
//
//  Created by 최은성 on 2021/12/28.
//

import UIKit
import NMapsMap
import CoreLocation

// SFSafariViewController 사용을 위한 프레임워크 반입 정의
import SafariServices

class ViewController: UIViewController {
    
    let locationManager = CLLocationManager()
    
    @IBOutlet weak var map: NMFMapView!
    @IBOutlet weak var searchTextField: UITextField!

    let totalString = TotalString()

    var markers = [NMFMarker]()

    var searchName:String = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchTextField.delegate = self
                
        locationManager.delegate = self
        getLocationUsagePermission()
        
        self.locationManager.requestWhenInUseAuthorization()
        locationManager.requestLocation()
        
        let mapView = NMFMapView(frame: map.frame)
        map.addSubview(mapView)
        
        mapView.touchDelegate = self
        
        let cameraUpdate = NMFCameraUpdate(scrollTo: NMGLatLng(lat: locationManager.location?.coordinate.latitude ?? 0, lng: locationManager.location?.coordinate.longitude ?? 0))
        cameraUpdate.animation = .easeIn
        mapView.moveCamera(cameraUpdate)
                    
        mapView.positionMode = .direction

        
        
        // 마커 여러개 띄우기
        for i in 0...totalString.str.count-1 {
            markers.append(NMFMarker()) // markers의 모든 원소를 인스턴스를 만들지 말고 하나씩 해야 제대로 나온다.
            markers[i].position = NMGLatLng(lat: totalString.str[i].lat, lng: totalString.str[i].lng)
            markers[i].mapView = mapView
            // 마커 아래 캡션 넣기
            var addressName = totalString.str[i].name
            // 각 마커에 해당하는 곳의 식당 이름 안에 "+"가 있을 경우 " "으로 바꿔줌
            if addressName.contains("+") {
                addressName = addressName.replacingOccurrences(of: "+", with: " ")
            }
            markers[i].captionText = addressName
            // 마커와 지도 심볼 간 겹쳤을 때 시인성이 떨어지는 것을 방지하기 위해
            markers[i].isHideCollidedSymbols = true
            markers[i].width = 30
            markers[i].height = 45
        }

        // 마커 클릭 이벤트
        for i in 0...totalString.str.count-1 {
            markers[i].touchHandler = { (overlay) in
                print("touch marker")
                let name = self.totalString.str[i].name.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
                // slat, slng, sname을 입력하지 않으면 기본값인 사용자의 현 위치로 표시된다.
                let url = URL(string: "nmap://route/walk?dlat=\(self.totalString.str[i].lat)&dlng=\(self.totalString.str[i].lng)&dname=\(name)&appname=com.eunsung-dev.what-to-eat")!

                let appStoreURL = URL(string: "http://itunes.apple.com/app/id311867728?mt=8")!
                if UIApplication.shared.canOpenURL(url) {
                  UIApplication.shared.open(url)
                } else {
                  UIApplication.shared.open(appStoreURL)    // 네이버 지도가 안깔려 있을 경우 앱스토어로 이동
                }
                
                return true
            }
        }
    }
}

extension ViewController: CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        if let location = locations.last {
            let lat = location.coordinate.latitude
            let lon = location.coordinate.longitude
            print("lat: ",lat)
            print("lon: ",lon)
        }
    }
    
    // 반드시 있어야 함.
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error)
    }

    func getLocationUsagePermission() {
            self.locationManager.requestWhenInUseAuthorization()

        }

    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
            switch status {
            case .authorizedAlways, .authorizedWhenInUse:
                print("GPS 권한 설정됨")
                self.locationManager.startUpdatingLocation() // 중요!
            case .restricted, .notDetermined:
                print("GPS 권한 설정되지 않음")
                getLocationUsagePermission()
            case .denied:
                print("GPS 권한 요청 거부됨")
                getLocationUsagePermission()
            default:
                print("GPS: Default")
            }
        }

}

//MARK: - MapView Touch Delegate

 extension ViewController: NMFMapViewTouchDelegate {
     func mapView(_ mapView: NMFMapView, didTapMap latlng: NMGLatLng, point: CGPoint) {
         print("\(latlng.lat), \(latlng.lng)")
     }
 }

//MARK: - UITextFieldDelegate

extension ViewController: UITextFieldDelegate {
    @IBAction func searchPressed(_ sender: UIButton) {
        searchTextField.endEditing(true)
        print(searchTextField.text!)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        searchTextField.endEditing(true)
        print(searchTextField.text!)
        return true
    }
    
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        if textField.text != "" {
            return true
        } else {
            textField.placeholder = "입력해주세요"
            return false
        }
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        if let name = searchTextField.text {
            searchName = name
            print("저장: \(searchName)")
            for i in 0...totalString.str.count-1 {
                if totalString.str[i].name == searchName {
                    print("존재합니다")
                    // 마커 색상 지정
                    markers[i].iconTintColor = UIColor.red
                }
            }
        }
        
        searchTextField.text = ""
    }

    // 텍스트필드 밖을 클릭할 때 키보드를 내린다.
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
         self.view.endEditing(true)
   }

}
